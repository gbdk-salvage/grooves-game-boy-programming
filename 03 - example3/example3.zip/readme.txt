Grooves GameBoy C files

To use the enclosed files you will need :

1.  An emulator such as VGB.EXE for your platform, to run the ROM
    image (*.GB)

2.  Pascals GBDK, if you want to alter and re-complie my example 
    C files.

I have enclosed a file EXAMPLE.BAT to re-compile the example into a ROM
image to use with an emulator.

After installing GBDK, extract this archive to C:\GBDK-2.0\examples\ 
for the BAT file to work.
Note : The BAT file will probably only work for DOS/WIN.

Have fun !

stephen.blanksby@virgin.net
http://freespace.virgin.net/stephen.blanksby