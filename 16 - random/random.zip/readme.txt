Grooves GameBoy C files

To use the enclosed files you will need :

1.  An emulator such as VGB.EXE for your platform, to run the ROM
    image (*.GB)

2.  Pascals GBDK, if you want to alter and re-complie my example 
    C files.

I have stopped including the make.bat files, as most people seem to
using GB Dev Studio. If you want these back please tell me....

Have fun !

stephen.blanksby@virgin.net
http://freespace.virgin.net/stephen.blanksby